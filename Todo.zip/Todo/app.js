var list = document.getElementById("list");

function todo_item() {
  var todo_item = document.getElementById("todo_item");

  var li = document.createElement("li");
  var litext = document.createTextNode(todo_item.value);
  li.appendChild(litext);

  var DelBtn = document.createElement("button");
  var DeletText = document.createTextNode("Delete");
  DelBtn.appendChild(DeletText);
  DelBtn.setAttribute("class", "btn");
  DelBtn.setAttribute("onclick", "DeleteItem(this)");

  li.appendChild(DelBtn);
  list.appendChild(li);

  todo_item.value = "";
  //   console.log(li);

  /////////  /////EDIT
  var EditBtn = document.createElement("button");
  var EditText = document.createTextNode("EditText");
  EditBtn.appendChild(EditText);
  EditBtn.setAttribute("class", "btnn");
  li.appendChild(EditBtn);
  EditBtn.setAttribute("onclick", "EditItem(this)");
}

function DeleteItem(e) {
  e.parentNode.remove();
}

function DeleteAll() {
  list.innerHTML = "";
}

function EditItem(e) {
  var val = e.parentNode.firstChild.nodeValue;
  var editvalue = prompt("Enter your edit value", val);
  val = e.parentNode.firstChild.nodeValue = editvalue;
  console.log(e.parentNode.firstChild);
}
